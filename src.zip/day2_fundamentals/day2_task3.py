# -*- coding: utf-8 -*-
"""
Created on Tue Feb  3 12:05:29 2026

@author: User
"""

itemname="Laptop";
quantity=4;
price =49000.99;
in_stock=True;
total_cost=(quantity*price);
print("Total cost:",total_cost);
print(f"Item:{itemname}, Qty: {quantity}, Price: {price}, Available:{in_stock}")
