# -*- coding: utf-8 -*-
"""
Created on Tue Feb  3 11:37:53 2026

@author: User
"""
name=input("enter your name");
age=int(input("enter your current  age"));
newage=age+4;
print(f"Hey {name},you will be {newage} years old in 2030");

